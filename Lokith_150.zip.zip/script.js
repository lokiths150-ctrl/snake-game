const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let snake, direction, food, score, gameLoop;

document.addEventListener("keydown", changeDirection);

function startGame() {
  document.getElementById("startScreen").classList.add("hidden");
  document.getElementById("gameScreen").classList.remove("hidden");
  initGame();
}

function initGame() {
  snake = [{ x: 200, y: 200 }];
  direction = "RIGHT";
  score = 0;
  document.getElementById("score").innerText = "Score: 0";
  placeFood();
  gameLoop = setInterval(drawGame, 150);
}

function changeDirection(e) {
  if (e.key === "ArrowUp" && direction !== "DOWN") direction = "UP";
  if (e.key === "ArrowDown" && direction !== "UP") direction = "DOWN";
  if (e.key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
  if (e.key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
}

function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  snake.forEach(part => {
    ctx.fillStyle = "lime";
    ctx.fillRect(part.x, part.y, 20, 20);
  });

  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, 20, 20);

  moveSnake();
}

function moveSnake() {
  let head = { ...snake[0] };

  if (direction === "UP") head.y -= 20;
  if (direction === "DOWN") head.y += 20;
  if (direction === "LEFT") head.x -= 20;
  if (direction === "RIGHT") head.x += 20;

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    score++;
    document.getElementById("score").innerText = "Score: " + score;
    placeFood();
  } else {
    snake.pop();
  }

  checkGameOver();
}

function placeFood() {
  food = {
    x: Math.floor(Math.random() * 20) * 20,
    y: Math.floor(Math.random() * 20) * 20
  };
}

function checkGameOver() {
  const head = snake[0];

  if (
    head.x < 0 || head.y < 0 ||
    head.x >= canvas.width || head.y >= canvas.height
  ) {
    endGame();
  }

  for (let i = 1; i < snake.length; i++) {
    if (head.x === snake[i].x && head.y === snake[i].y) {
      endGame();
    }
  }
}

function endGame() {
  clearInterval(gameLoop);
  document.getElementById("gameScreen").classList.add("hidden");
  document.getElementById("gameOverScreen").classList.remove("hidden");
  document.getElementById("finalScore").innerText = "Final Score: " + score;
}

function restartGame() {
  document.getElementById("gameOverScreen").classList.add("hidden");
  document.getElementById("gameScreen").classList.remove("hidden");
  initGame();
}
