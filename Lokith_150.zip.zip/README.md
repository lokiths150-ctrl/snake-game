# Snake Game

## Team Members
- Lokith N
- Manoj M
- Sai krishnar M 

## Game Description
This is a browser-based Snake Game developed using HTML, CSS, and JavaScript. 
The player controls a snake that grows as it eats food while avoiding walls and its own body.

## How to Play
- Click "Start Game"
- Use Arrow Keys to move the snake
- Eat food to increase score
- Game ends on collision

## Features
- Start Screen
- Gameplay Screen
- Game Over Screen
- Score tracking
- Restart option

## Concepts Used
- Variables and Data Types
- Conditional Statements
- Loops
- Functions
- Arrays
- DOM Manipulation
- Event Handling

## Technologies Used
- HTML
- CSS
- JavaScript

## GitHub Repository
(Add your GitHub repository link here)
